#include <iostream>
#include <vector>
#include <opencv2/opencv.hpp>
#include <locale.h>
using namespace std;
using namespace cv;

void bounding_Box(Mat binario){
    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;
    RNG rng(12345);
    findContours(binario, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );
    vector<vector<Point> > contours_poly( contours.size() );
    vector<Rect> boundRect( contours.size() );
    vector<Point2f>center( contours.size() );
    vector<float>radius( contours.size() );

    for(int i = 0; i < contours.size(); i++){
    approxPolyDP( Mat(contours[i]), contours_poly[i], 1, true );
    boundRect[i] = boundingRect( Mat(contours_poly[i]) );
    minEnclosingCircle( (Mat)contours_poly[i], center[i], radius[i] );
    }


    Mat drawing = Mat::zeros( binario.size(), CV_8UC3 );
    for( int i = 0; i< contours.size(); i++ ){
        Scalar color = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
        Scalar color_rectangle = Scalar (0,0,255);
        drawContours( drawing, contours_poly, i, color, 1, 8, vector<Vec4i>(), 0, Point() );
        rectangle( drawing, boundRect[i].tl(), boundRect[i].br(), color_rectangle, 2, 8, 0 );
    }
    //namedWindow( "Contours", CV_WINDOW_AUTOSIZE );
    //imshow( "Contours", drawing );
}

Mat Box(Mat binario){
    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;
    RNG rng(12345);
    findContours(binario, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );
    vector<vector<Point> > contours_poly( contours.size() );
    vector<Rect> boundRect( contours.size() );
    vector<Point2f>center( contours.size() );
    vector<float>radius( contours.size() );

    for( int i = 0; i < contours.size(); i++ ){
    approxPolyDP( Mat(contours[i]), contours_poly[i], 1, true );
    boundRect[i] = boundingRect( Mat(contours_poly[i]) );
    minEnclosingCircle( (Mat)contours_poly[i], center[i], radius[i] );
    }


    Mat drawing = Mat::zeros( binario.size(), CV_8UC3 );
    for( int i = 0; i< contours.size(); i++ ){
        Scalar color = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
        Scalar color_rectangle = Scalar (0,0,255);
        drawContours( drawing, contours_poly, i, color, 1, 8, vector<Vec4i>(), 0, Point() );
        rectangle( drawing, boundRect[i].tl(), boundRect[i].br(), color_rectangle, 2, 8, 0 );
    }
    namedWindow( "Contours e Box", CV_WINDOW_AUTOSIZE );
    imshow( "Contours e Box", drawing );
    return drawing;
}
void Detecta(Mat imagem){
    Mat dst;
    imagem.convertTo(dst, CV_8U);
    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;
    findContours(dst, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );

    double area, area_total;
    int quantidade=0;
    for( int i = 0; i< contours.size(); i++ ){
        area = contourArea(contours[i]);
        area_total = area_total + area;
        quantidade += 1;

    //cout << "Área de cada Anomalia =" << area << endl ;
    } if(area==0){
            cout<<"Nenhuma anomalia detectada!"<<endl;
            }else{
            cout<<"\a\nAnomalia detectada!"<<endl;
            bounding_Box(imagem);
            cout<<"Área total da(s) anomalia(s) detectada(s): "<< area_total<<" pixels"<<endl;
            cout<<"Quantidade de anomalias detectadas: "<<quantidade<<endl;
        }

    }
int main(int argc, char** argv) {
    setlocale(LC_ALL,"Portuguese");

    Mat Img = imread("img3.jpg", 0);
    Mat Img_color_cinza;
    cvtColor(Img,Img_color_cinza, COLOR_GRAY2BGR);
    if(Img.empty()){
       cout << "Falha ao carregar imagem" << endl;
        return -1;
    }else{

    cout<<"---------------------------------------------------------------"<<endl;
    cout<<"--Detector de anomalias em mamas-------------------------------"<<endl;
    cout<<"\nCom intuito de estabeler grau de prioridade de atendimento,  "<<endl;
    cout<<"e auxiliar no diagnóstico médico.                              "<<endl;
    cout<<"---------------------------------------------------------------"<<endl;
    cout<<"Diagnóstico: "<<endl;

    Mat tozero;
    /// Função que recorta as supostas anomalias contrastadas
    threshold(Img,tozero, 170, 255, THRESH_TOZERO);
    imshow("Threshold To zero",tozero);

    Mat binario1;
    threshold(tozero,binario1, 40, 255, CV_THRESH_BINARY);
    imshow("Converte para binario",binario1);


    Mat binario;
    threshold(tozero, binario, 40, 255, CV_THRESH_BINARY);

    medianBlur(binario,binario,3);


    Mat Close = getStructuringElement( MORPH_CROSS,Size(3 , 3),Point( 1, 1 ) );

    //erode(binario,binario,Close);
    dilate(binario,binario,Close);
    dilate(binario,binario,Close);
    dilate(binario,binario,Close);
    erode(binario,binario,Close);

    imshow("Binario Dilatado", binario);
    imshow("Imagem escala cinza", Img);

    Mat resultado = binario1 - binario;
    Mat resultado2= resultado+binario;

    imshow("Exclusao",resultado);

    dilate(resultado2,resultado2,Close);
    dilate(resultado2,resultado2,Close);
    dilate(resultado2,resultado2,Close);
    medianBlur(resultado2,resultado2,3);
    Detecta(resultado2);

    imshow("Uniao",resultado2);

    Mat Superposicao;
    Superposicao = Box(resultado2)+Img_color_cinza;
    imshow("Superposicao", Superposicao);

    }
waitKey(0);
return 0;
}


